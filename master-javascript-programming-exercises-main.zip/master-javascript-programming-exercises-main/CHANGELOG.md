# Changelog

1.  Added exercises from 1 to 20 by Mike Berrio
2. On July 20, 2020: Added exercises from 20 to 30 to Mike Berrio (i know that it is conflicting with Kristina).

# Planning

1. Added exercises from 21 to  40 to Kristina Frants
3. Added exercises from 41 to  60 to Kevin Castillo
4. Added exercises from 61 to  80 to Eduard Chiticari
5. Added exercises from 81 to 100 to Jorge Montes

# Sep 24

I tested the first exercises until 09, we need to test them all.