# `073` countNumberOfKeys

## 📝 Instructions:

1. Write a function called `countNumberOfKeys`. Given an object, `countNumberOfKeys` returns how many properties the given object has.

## Example:

```Javascript
let obj = {
  a: 1,
  b: 2,
  c: 3
};
let output = countNumberOfKeys(obj);
console.log(output); // --> 3
```