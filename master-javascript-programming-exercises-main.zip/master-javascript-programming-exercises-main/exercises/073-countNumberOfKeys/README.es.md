# `073` countNumberOfKeys

## 📝 Instrucciones:

1. Escribe una función llamada `countNumberOfKeys`. Dado un objeto, `countNumberOfKeys` regresa tantas propiedades como el objeto dado tenga.

## Ejemplo:

```Javascript
let obj = {
  a: 1,
  b: 2,
  c: 3
};
let output = countNumberOfKeys(obj);
console.log(output); // --> 3
```