function countNumberOfKeys(obj) {
    // your code here

}