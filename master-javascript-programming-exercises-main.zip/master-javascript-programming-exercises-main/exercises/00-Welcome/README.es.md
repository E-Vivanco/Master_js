# ¡Bievenido!
 
Este es el último de una serie de ejercicios publicados para practicar Javascript desde cero por [@alesanchezr](https://twitter.com/alesanchezr) y [4GeeksAcademy](https://4geeksacademy.com).

Si no haz completado los otros ejercicios te recomiendo que empieces por alli:

1. [JS Beginner](https://github.com/4GeeksAcademy/javascript-beginner-exercises-tutorial).

2. [Arreglos](https://github.com/4GeeksAcademy/javascript-arrays-exercises-tutorial).

3. [Functions](https://github.com/4GeeksAcademy/javascript-functions-exercises-tutorial).

Si ya los haz completado o te sientes confiado puedes apretar el botón `next →` en la parte superior derecha de estas instrucciones para empezar a practicar. ¡Mucho Exito!