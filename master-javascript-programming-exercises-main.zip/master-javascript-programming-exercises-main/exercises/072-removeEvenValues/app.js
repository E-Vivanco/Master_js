function removeEvenValues(obj) {
    // your code here
    
}