// Write your function here
function isSameLength(word1, word2){
    return word1.length === word2.length
}