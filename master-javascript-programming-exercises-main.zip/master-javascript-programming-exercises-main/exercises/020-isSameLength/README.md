# `020` isSameLength

## 📝 Instructions: 

1. Write a function called `isSameLength`. Given two words, `isSameLength` returns `true` if the given words have the same length. Otherwise it returns `false`.

## Example:

```Javascript
let output = isSameLength('words', 'super');
console.log(output); // --> true
```