# `020` isSameLength

## 📝 Instructiones:

1. Escribe una función llamada `isSameLength`. Dado dos palabras, `isSameLength` retorna `true`si ambas palabras tienen la misma cantidad de letras. De lo contrario retorna `false`.

## Ejemplo:

```Javascript
let output = isSameLength('words', 'super');
console.log(output); // --> true
```