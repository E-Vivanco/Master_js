function removeFromBackOfNew(arr) {
  // your code here
  
}