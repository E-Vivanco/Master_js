// let split = str.split('  ');
// let joinSpace = split.join(' ');
// return joinSpace