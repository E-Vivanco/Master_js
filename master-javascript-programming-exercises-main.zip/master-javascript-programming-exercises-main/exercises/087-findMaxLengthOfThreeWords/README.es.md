# `087` findMaxLengthOfThreeWords

## 📝 Instrucciones:

1. Escribe un función llamada `findMaxLengthOfThreeWords`. Dado 3 palabras, `findMaxLengthOfThreeWords` retorna la cantidad de letras de la palabra más larga.

## Ejemplo:

```js
let output = findMaxLengthOfThreeWords('a', 'be', 'see');
console.log(output); // --> 3
```