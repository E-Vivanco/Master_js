# `087` findMaxLengthOfThreeWords

## 📝 Instructions:

1. Write a function called `findMaxLengthOfThreeWords`. Given 3 words, `findMaxLengthOfThreeWords` returns the length of the longest word.

## Example:

```js
let output = findMaxLengthOfThreeWords('a', 'be', 'see');
console.log(output); // --> 3
```