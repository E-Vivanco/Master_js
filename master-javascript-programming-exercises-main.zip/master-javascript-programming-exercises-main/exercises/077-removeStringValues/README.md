# `077` removeStringValues

## 📝 Instructions:

1. Write a function called `removeStringValues`. Given an object, `removeStringValues` removes any properties whose values are strings.

## Example:

```Javascript
let obj = {
  name: 'Sam',
  age: 20
}
removeStringValues(obj);
console.log(obj); // { age: 20 }
```