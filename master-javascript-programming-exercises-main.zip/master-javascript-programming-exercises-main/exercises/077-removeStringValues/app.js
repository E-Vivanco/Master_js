let obj = {
    name: 'Sam',
    age: 20
}

function removeStringValues(obj) {
    // your code here
    
}

removeStringValues(obj);
console.log(obj); // { age: 20 }
