# `077` removeStringValues

## 📝 Instrucciones:

1. Escribe una función llamada `removeStringValues`. Dado un objeto, `removeStringValues` elimina cualquier propiedad en el objeto cuyo valor sea string.

## Ejemplo:

```Javascript
let obj = {
  name: 'Sam',
  age: 20
}
removeStringValues(obj);
console.log(obj); // { age: 20 }
```