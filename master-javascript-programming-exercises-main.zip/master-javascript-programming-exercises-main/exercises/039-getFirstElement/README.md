# `039` getFirstElement

## 📝 Instructions:

1. Write a function called `getFirstElement`. Given an array, `getFirstElement` returns the first element of the given array.


## Example:

```Javascript
let output = getFirstElement([1, 2, 3, 4, 5]);
console.log(output); // --> 1
```

## 💡 Hint:

+ If the given array has a length of 0, it should return `undefined`.