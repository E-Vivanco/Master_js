function getFirstElement(array) {
  // Add your code after this line

}

let output = getFirstElement([1, 2, 3, 4, 5]);
console.log(output); // --> 1