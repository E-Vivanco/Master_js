# `039` getFirstElement

## 📝 Instrucciones:

1. Escribe una función llamada `getFirstElement`. Dado un array, `getFirstElement` regresa el primer elemento del array.


## Ejemplo:

```Javascript
let output = getFirstElement([1, 2, 3, 4, 5]);
console.log(output); // --> 1
```

## 💡 Pista:

+ Si la longitud del arreglo dado es 0, debería regresar `undefined`.
