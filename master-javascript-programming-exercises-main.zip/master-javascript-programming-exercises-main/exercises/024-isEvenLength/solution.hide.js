// Write your function here
function isEvenLength(word){
    return word.length % 2 == 0
}