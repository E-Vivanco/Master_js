# `024` isEvenLength

## 📝 Instrucciones:

1. Escribe una función llamada `isEvenLength`. Dada una palabra, `isEvenLength` retorna `true` si la cantidad de letras que tiene la palabra es par, de lo contrario retorna `false`.

## Ejemplo:

```Javascript
let output = isEvenLength('wow');
console.log(output); // --> false
```
