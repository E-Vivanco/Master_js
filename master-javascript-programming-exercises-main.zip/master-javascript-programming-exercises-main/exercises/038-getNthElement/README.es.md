# `038` getNthElement

## 📝 Instrucciones:

1. Escribe una función llamada `getNthElement`. Dado un array y un número entero, `getNthElement` regresa el elemento del array, ubicado dentro de la posición dada.

## Ejemplo:

```Javascript
let output = getNthElement([1, 3, 5], 1);
console.log(output); // --> 3
```

## 💡 Pista:

+ Si el arreglo tiene una longitud 0, debería regresar `undefined`.
