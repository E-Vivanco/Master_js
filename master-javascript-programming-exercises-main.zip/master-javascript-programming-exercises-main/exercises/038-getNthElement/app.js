function getNthElement(array, n) {
  // Add your code after this line
  
}