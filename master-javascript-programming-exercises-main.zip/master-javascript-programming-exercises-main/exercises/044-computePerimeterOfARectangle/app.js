function computePerimeterOfARectangle(length, width) {
  // your code here
}
let output = computePerimeterOfARectangle(5, 2);
console.log(output);