# `044` computePerimeterOfARectangle

## 📝 Instructions:

1. Write a function called `computePerimeterOfARectangle`. Given a length and a width describing a rectangle, `computePerimeterOfARectangle` returns its perimeter.

## Example:

```Javascript
let output = computePerimeterOfARectangle(5, 2);
console.log(output); // --> 14
```