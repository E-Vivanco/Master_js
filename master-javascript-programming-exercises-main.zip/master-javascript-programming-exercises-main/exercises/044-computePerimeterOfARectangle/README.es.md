# `044` computePerimeterOfARectangle

## 📝 Instrucciones:

1. Escribe una función llamada `computePerimeterOfARectangle`. Dado el largo y ancho de un rectángulo, `computePerimeterOfARectangle` regresa su perímetro.

## Ejemplo:

```Javascript
let output = computePerimeterOfARectangle(5, 2);
console.log(output); // --> 14
```