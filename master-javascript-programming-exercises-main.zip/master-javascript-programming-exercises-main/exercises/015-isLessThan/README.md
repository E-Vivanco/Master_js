# `015` isLessThan

## 📝 Instructions:

1. Write a function called `isLessThan`. Given 2 numbers, `isLessThan` returns `true` if `num2` is less than `num1`. Otherwise it returns `false`.

## Example:

```Javascript
let output = isLessThan(9, 4);
console.log(output); // --> true
```