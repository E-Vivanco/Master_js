# `015` isLessThan

## 📝 Instrucciones:

1. Escribe una función llamada `isLessThan`. Dado 2 números, `isLessThan` retorna `true` si `num2` es menor que `num1`. De lo contrario retorna `false`.

## Ejemplo:

```Javascript
let output = isLessThan(9, 4);
console.log(output); // --> verdadero
```