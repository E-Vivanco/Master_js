function isLessThan(num1, num2) {
  // your code here
  return (num2 < num1);
}
