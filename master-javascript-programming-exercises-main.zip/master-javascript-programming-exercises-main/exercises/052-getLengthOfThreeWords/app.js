function getLengthOfThreeWords(word1, word2, word3) {
  // your code here
}