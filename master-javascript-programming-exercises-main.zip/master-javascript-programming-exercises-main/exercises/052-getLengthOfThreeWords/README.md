# `052` getLengthOfThreeWords

## 📝 Instructions:

1. Write a function called `getLengthOfThreeWords`. Given 3 words, `getLengthOfThreeWords` returns the sum of their lengths.

## Example:

```Javascript
let output = getLengthOfThreeWords('some', 'other', 'words');
console.log(output); // --> 14
```

## 💡 Hint: 

+ Remember to use the function `length` on strings to know it's length.