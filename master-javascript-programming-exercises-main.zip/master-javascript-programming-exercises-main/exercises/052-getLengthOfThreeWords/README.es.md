# `052` getLengthOfThreeWords

## 📝 Instrucciones:

1. Escribe una función llamada `getLengthOfThreeWords`. Dadas 3 palabras, `getLengthOfThreeWords` regresa la suma de sus letras.

## Ejemplo:

```Javascript
let output = getLengthOfThreeWords('some', 'other', 'words');
console.log(output); // --> 14
```

## 💡 Hint: 

+ Recuerda de usar `length` para saber la longitud de una cadena / string.