# `086` findMinLengthOfThreeWords

## 📝 Instructions: 

1. Write a function called `findMinLengthOfThreeWords`. Given 3 words, `findMinLengthOfThreeWords` returns the length of the shortest word.

## Example:

```js
let output = findMinLengthOfThreeWords('a', 'be', 'see');
console.log(output); // --> 1
```