# `086` findMinLengthOfThreeWords

## 📝 Instrucciones 

1. Escribe una función llamada `findMinLengthOfThreeWords`. Dado 3 palabras, `findMinLengthOfThreeWords` retorna la cantidad de letras de la palabra más corta.

## Ejemplo:

```js
let output = findMinLengthOfThreeWords('a', 'be', 'see');
console.log(output); // --> 1
```