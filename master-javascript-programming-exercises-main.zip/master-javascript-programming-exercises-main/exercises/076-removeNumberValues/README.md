# `076` removeNumberValues

## 📝 Instructions:

1. Write a function called `removeNumberValues`. Given an object, `removeNumberValues` removes any properties whose values are numbers.

## Example:

```Javascript
let obj = {
  a: 2,
  b: 'remaining',
  c: 4
};
removeNumberValues(obj);
console.log(obj); // --> { b: 'remaining' }
```