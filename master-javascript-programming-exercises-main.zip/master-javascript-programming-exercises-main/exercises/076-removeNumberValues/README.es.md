# `76` removeNumberValues

## 📝 Instrucciones:

1. Escribe una función llamada `removeNumberValues`. Dado un objeto, `removeNumberValues` elimina cualquier propiedad cuyos valores sean números.

## Ejemplo:

```Javascript
let obj = {
  a: 2,
  b: 'remaining',
  c: 4
};
removeNumberValues(obj);
console.log(obj); // --> { b: 'remaining' }
```