let obj = {
    a: 2,
    b: 'remaining',
    c: 4
};
function removeNumberValues(obj) {
    // your code here
    
}

removeNumberValues(obj);
console.log(obj); // --> { b: 'remaining' }