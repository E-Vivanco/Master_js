// Write your function here

function computeAreaOfATriangle(a,b){
    return (a * b) / 2
}