# `027` computeAreaOfATriangle

## 📝 Instrucciones:

1. Escribe una función llamada `computeAreaOfATriangle`. Dado la base y altura de un triangulo, `computeAreaOfATriangle` retorna el área de un triángulo.

## Ejemplo:

```Javascript
let output = computeAreaOfATriangle(4, 6);
console.log(output); // --> 12
```