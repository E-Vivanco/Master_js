# `027` computeAreaOfATriangle

## 📝 Instructions:

1. Write a function called `computeAreaOfATriangle`. Given the base and height of a triangle `computeAreaOfATriangle` returns its area.

## Example:

```Javascript
let output = computeAreaOfATriangle(4, 6);
console.log(output); // --> 12
```