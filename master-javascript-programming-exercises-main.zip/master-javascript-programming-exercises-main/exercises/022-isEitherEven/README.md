# `022` isEitherEven

## 📝 Instructions:

1. Write a function called `isEitherEven`. Given 2 numbers, `isEitherEven` returns `true` if one of the numbers is even, otherwise it should return `false`.

## Example:

```Javascript
let output = isEitherEven(1, 4);
console.log(output); // --> true
```
