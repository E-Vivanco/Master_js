# `022` isEitherEven

## 📝 Instrucciones:

1. Escribe una función llamada `isEitherEven`, que dados 2 números, `isEitherEven` retorna `true` si uno de los números es par, de lo contrario retorna `false`.

## Ejemplo:

```Javascript
let output = isEitherEven(1, 4);
console.log(output); // --> true
```
