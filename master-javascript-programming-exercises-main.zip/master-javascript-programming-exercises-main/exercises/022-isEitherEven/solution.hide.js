// Write your function here
function isEitherEven(n1, n2) {
  if (n1 % 2 == 0 || n2 % 2 == 0) return true;
  else return false;
}
