// Write your function here
function isOddLength(word){
    
}