# `023` isOddLength

## 📝 Instructions:

1. Write a function called `isOddLength`. Given a word, `isOddLength` returns `true` if the length of the given word is odd, otherwise it returns `false`.

## Example:

```Javascript
let output = isOddLength('special');
console.log(output); // --> true
```
