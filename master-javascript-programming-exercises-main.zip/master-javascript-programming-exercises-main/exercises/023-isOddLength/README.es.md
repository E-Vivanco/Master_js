# `023` isOddLength

## 📝 Instrucciones:

1. Escribe una función llamada `isOddLength`. Dada una palabra, `isOddLength` retorna `true` si la cantidad de letras que tiene la palabra es impar, de lo contrario retorna `false`.

## Ejemplo:

```Javascript
let output = isOddLength('special');
console.log(output); // true
```
