function isPersonOldEnoughToDrink(person) {
  // Add your code after this line
  
}