# `057` getAllElementsButLast

## 📝 Instrucciones:

1. Escribe una función llamada `getAllElementsButLast`. Dado un array, `getAllElementsButLast` regresa un array con todos los elementos excepto el último.

## Ejemplo:

```Javascript
let input = [1, 2, 3, 4];
let output = getAllElementsButLast(input);
console.log(output); // --> [1, 2 , 3]
```