# `057` getAllElementsButLast

## 📝 Instructions:

1. Write a function called `getAllElementsButLast`. Given an array, `getAllElementsButLast` returns an array with all the elements but the last.

## Example:


```Javascript
let input = [1, 2, 3, 4];
let output = getAllElementsButLast(input);
console.log(output); // --> [1, 2 , 3]
```