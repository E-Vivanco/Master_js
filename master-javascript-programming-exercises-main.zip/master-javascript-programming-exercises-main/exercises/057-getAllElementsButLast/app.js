function getAllElementsButLast(array) {
    // your code here

}