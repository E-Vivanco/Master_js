# `042` addToBack

## 📝 Instructions:

1. Write a function called `addToBack`. Given an array and an element, `addToBack` returns the given array with the given element added to the end.

## Example:

```Javascript
let output = addToBack([1, 2], 3);
console.log(output); // -> [1, 2, 3]
```

## 💡 Hint:

+ It should be the SAME array, not a new array.