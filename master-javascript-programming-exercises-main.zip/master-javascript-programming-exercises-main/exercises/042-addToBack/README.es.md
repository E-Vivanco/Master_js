# `042` addToBack

## 📝 Instrucciones:

1. Escribe una función llamada `addToBack`. Dado un array y un elemento, `addToBack` regresa el array con el elemento añadido al final.

## Ejemplo:

```Javascript
let output = addToBack([1, 2], 3);
console.log(output); // -> [1, 2, 3]
```

## 💡 Pista:

+ Debería ser el MISMO array, no uno nuevo.