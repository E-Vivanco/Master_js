function filterEvenLengthWords(words) {
    // your code here
}

let output = filterEvenLengthWords(['word', 'words', 'word', 'words']);
console.log(output); // --> ['word', 'word']