# `105` filterEvenLengthWords

## 📝 Instructions:

1. Write a function called `filterEvenLengthWords`. Given an array of strings, `filterEvenLengthWords` returns an array containing only the elements of the given array whose length is an even number.

## Example:

```Js
let output = filterEvenLengthWords(['word', 'horse', 'car', 'computer']);
console.log(output); // --> ['word', 'computer']
```
