# `105` filterEvenLengthWords

## 📝 Instrucciones:

1. Escribe una función llamada `filterEvenLengthWords`. Dado un array de strings, `filterEvenLengthWords` retorna un array que contenga solo los elementos del array cuya longitud es un número par.

## Ejemplo:

```Js
let output = filterEvenLengthWords(['word', 'horse', 'car', 'computer']);
console.log(output); // --> ['word', 'computer']
```
