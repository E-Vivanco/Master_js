# `082` addToBackOfNew

## 📝 Instrucciones: 

1. Escribe una función llamada `addToBackOfNew`. Dado un array y un elemento, `addToBackOfNew` retorna un clon de ese array dado con el elemento añadido al final.

## Ejemplo:

```js
let input = [1, 2];
let output = addToBackOfNew(input, 3);
console.log(input); // --> [1, 2]
console.log(output); // --> [1, 2, 3]
```

## 💡 Pista:

+ Debería crear un nuevo array y no modificar el array original.
