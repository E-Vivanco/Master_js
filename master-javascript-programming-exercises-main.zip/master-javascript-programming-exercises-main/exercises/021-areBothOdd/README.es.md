# `021` areBothOdd

## 📝 Instrucciones:

1. Escribe una función llamada `areBothOdd`, que dados 2 números, `areBothOdd` retorna `true` si ambos números son impares, de lo contrario retorna `false`.

## Ejemplo:

```js
let output = areBothOdd(1, 3);
console.log(output); // --> true
```
