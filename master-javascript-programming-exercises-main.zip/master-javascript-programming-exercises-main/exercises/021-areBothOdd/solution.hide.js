// Write your function here
const areBothOdd = (a,b) => {
    return (a % 2 > 0) && (b % 2 >0)
}