# `021` areBothOdd

## 📝 Instructions

1. Write a function called `areBothOdd`. Given 2 numbers, `areBothOdd` returns `true` if both numbers are odd, otherwise it should return `false`.

## Example:

```Javascript
let output = areBothOdd(1, 3);
console.log(output); // --> true
```
