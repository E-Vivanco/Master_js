function isOldEnoughToDrinkAndDrive(age) {
  // your code here
}