function isOldEnoughToDrinkAndDrive(age) {
  // your code here
  return false;
}