# `004` isOldEnoughToDrinkAndDrive

## 📝 Instrucciones:

1. Escribe una función llamada `isOldEnoughToDrinkAndDrive` que dado un número, en este caso una edad, retorne si la persona de esa edad tiene la edad necesaria para beber y conducir legalmente en los Estados Unidos.

## Ejemplo:

```Javascript
let output = isOldEnoughToDrinkAndDrive(22);
console.log(output); // --> false
```

## 💡 Pista:

+ La edad legal para poder beber en los Estados Unidos es de 21 años.

+ La edad legal para poder conducir en los Estados Unidos es de 16 años.

+ Siempre es ilegal beber y conducir en los Estados Unidos.
