# `002` isOldEnoughToDrive

## 📝 Instrucciones:

Escribe una función llamada `isOldEnoughToDrive` que dado un número, en este caso una edad, `isOldEnoughToDrive` retorna si la persona de esa edad tiene la edad necesaria para conducir legalmente en los Estados Unidos.

## Ejemplo:

```javascript
let output = isOldEnoughToDrive(22);
console.log(output); // --> true
```

## 💡 Pista:

+ La edad legal para poder conducir en los Estados Unidos es de 16 años.
