function isOldEnoughToDrive(age) {
  // your code here
}