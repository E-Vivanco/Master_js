function isOldEnoughToDrive(age) {
  // your code here
  if(age > 16) return true;
  else return false;
}