function addProperty(obj, key) {
  // your code here
}