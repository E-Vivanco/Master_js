# `006` addProperty

## 📝 Instrucciones:

1. Escribe una función llamada `addProperty`. Dado un objeto y una key, `addProperty` agrega  la key al objeto con el valor `true`.

Luego. la función tiene que devolver el objeto.

## Ejemplo:

```Javascript
let myObj = {};
addProperty(myObj, 'myProperty');
console.log(myObj.myProperty); // --> true
```
