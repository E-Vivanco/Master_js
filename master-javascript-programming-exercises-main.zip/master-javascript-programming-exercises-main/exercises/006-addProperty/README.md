# `006` addProperty

## 📝 Instructions

1. Write a function called `addProperty`. Given an object, and a key, `addProperty` sets a new property on the given object with a value of `true`.

Then, the function must return the object.

## Example:

```Javascript
let myObj = {};
addProperty(myObj, 'myProperty');
console.log(myObj.myProperty); // --> true
```