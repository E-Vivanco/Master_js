let obj = {
  key: [1, 2, 3, 4, 5]
};

function getOddElementsAtProperty(obj, key) {
    // your code here
}

let output = getOddElementsAtProperty(obj, 'key');
console.log(output); // --> [1, 3, 5]