# `011` getLengthOfTwoWords

## 📝 Instructions:

1. Write a function called `getLengthOfTwoWords`. Given 2 words, `getLengthOfTwoWords` returns the *sum* of their lengths.

## Example:

```Javascript
let output = getLengthOfTwoWords('some', 'words');
console.log(output); // --> 9
```
