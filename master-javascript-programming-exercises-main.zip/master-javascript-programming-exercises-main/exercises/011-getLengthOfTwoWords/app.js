function getLengthOfTwoWords(word1, word2) {
  // your code here
}