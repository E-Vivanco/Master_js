function getLengthOfTwoWords(word1, word2) {
  // your code here
  return word1.length + word2.length
}