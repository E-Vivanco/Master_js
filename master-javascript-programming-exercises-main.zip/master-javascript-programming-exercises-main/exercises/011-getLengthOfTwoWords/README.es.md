# `011` getLengthOfTwoWords

## 📝 Instrucciones:

1. Escribe una función llamada `getLengthOfTwoWords`. Dado dos palabras, `getLengthOfTwoWords` retorna la *suma* de sus letras.

## Ejemplo:

```Javascript
let output = getLengthOfTwoWords('some', 'words');
console.log(output); // --> 9
```