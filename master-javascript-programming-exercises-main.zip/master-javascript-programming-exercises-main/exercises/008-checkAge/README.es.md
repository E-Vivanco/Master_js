# `008` checkAge

## 📝 Instrucciones:

1. Escribe una función llamada `checkAge`. Dado el nombre y la edad de una persona, `checkAge` retorna uno de estos dos mensajes:

- `¡Go home, {insert_name_here}!`, si son menores de 21.

- `¡Welcome {insert_name_here}!`, si son mayores de 21.

## Ejemplo:

```Javascript
let output = checkAge('Adrian', 22);
console.log(output); // --> '¡Welcome Adrian!'
```

## 💡 Pista:

+ Reemplaza `{insert_name_here}` ({inserta_nombre_aquí)} con el nombre dado. :)
