function checkAge(name, age) {
  // your code here
}