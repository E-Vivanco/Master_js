# `019` isOdd

## 📝 Instructions:

1. Write a function called `isOdd`. Given a number, `isOdd` returns `true` if the given number is odd. Otherwise it returns `false`.

## Example:

```Javascript
let output = isOdd(9);
console.log(output); // --> true
```