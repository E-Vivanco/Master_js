# `019` isOdd

## 📝 Instrucciones:

1. Escribe una función llamada `isOdd`. Dado un número, `isOdd` retorna `true` si el número es impar. De lo contrario retorna `false`.

## Ejemplo:

```Javascript
let output = isOdd(9);
console.log(output); // --> true
```
