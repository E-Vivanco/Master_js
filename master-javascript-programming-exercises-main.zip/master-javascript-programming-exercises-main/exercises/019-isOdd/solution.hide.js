// Write your function here
function isOdd(num){
    return num % 2 > 0;
}