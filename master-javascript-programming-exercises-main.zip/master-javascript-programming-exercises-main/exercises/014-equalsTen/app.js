function equalsTen(num) {
  // your code here
}