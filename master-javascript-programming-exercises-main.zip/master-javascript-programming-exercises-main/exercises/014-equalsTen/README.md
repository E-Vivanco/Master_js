# `014` equalsTen

## 📝 Instructions:

1. Write a function called `equalsTen`. Given a number, `equalsTen` returns `true` if the given number is 10. Otherwise it returns `false`.

## Example:

```Javascript
let output = equalsTen(9);
console.log(output); // --> false
```

## 💡 Hint

+ Remember to use three equals to compare exact values. [Read more about it here](https://bytearcher.com/articles/equality-comparison-operator-javascript)