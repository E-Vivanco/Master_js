# `014` equalsTen

## 📝 Instrucciones:

1. Escribe una función llamada `equalsTen`. Dado un número, `equalsTen` retorna `true` si ese número es igual a 10. De lo contrario retorna `false`.

## Ejemplo:

```Javascript
let output = equalsTen(9);
console.log(output); // --> false
```

## 💡 Pista

+ Recuerda usar tres signos iguales (===) para comparar valores exactos [Haz clic aquí para mayor info](https://bytearcher.com/articles/equality-comparison-operator-javascript)
