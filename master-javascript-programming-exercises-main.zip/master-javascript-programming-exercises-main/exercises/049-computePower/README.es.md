# `049` computePower

## 📝 Instrucciones:

1. Escribe una función llamada `computePower`. Dado un número y un exponente, `computePower` regresa el número, elevado al exponente. 

## Ejemplo:

```Javascript
let output = computePower(2, 3);
console.log(output); // --> 8
```
