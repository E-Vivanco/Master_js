# `049` computePower

## 📝 Instructions:

1. Write a function called `computePower`. Given a number and an exponent, `computePower` returns the given number, raised to the given exponent. 

## Example:

```Javascript
let output = computePower(2, 3);
console.log(output); // --> 8
```
