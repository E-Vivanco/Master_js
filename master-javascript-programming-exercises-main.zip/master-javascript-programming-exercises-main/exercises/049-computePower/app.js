function computePower(num, exponent) {
  // your code here
}
