# `061` countCharacter

## 📝 Instrucciones:

1. Escribe una función llamada `countCharacter`. Dado un string input y un caracter, `countCharacter` regresa el número de repeticiones del caracter dado en el string.

## Ejemplo:

```Javascript
let output = countCharacter('I am a hacker', 'a');
console.log(output); // --> 3
```