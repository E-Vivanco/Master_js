function countCharacter(str, char) {
    // your code here
    
}