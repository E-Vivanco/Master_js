# `061` countCharacter

## 📝 Instructions:

1. Write a function called `countCharacter`. Given a string input and a character, `countCharacter` returns the number of occurences of a given character in the given string.

## Example:

```Javascript
let output = countCharacter('I am a hacker', 'a');
console.log(output); // --> 3
```