# `048` computeAreaOfACircle

## 📝 Instrucciones:

1. Escribe una función llamada `computeAreaOfACircle`. Dado el radio de un círculo, `computeAreaOfACircle` regresa su área.

## Ejemplo:

```Javascript
let output = computeAreaOfACircle(4);
console.log(output); // --> 50.26548245743669
```