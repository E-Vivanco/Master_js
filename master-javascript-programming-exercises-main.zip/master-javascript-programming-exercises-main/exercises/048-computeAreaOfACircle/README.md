# `048` computeAreaOfACircle

## 📝 Instructions:

1. Write a function called `computeAreaOfACircle`. Given the radius of a circle, `computeAreaOfACircle` returns its area.

## Example:

```Javascript
let output = computeAreaOfACircle(4);
console.log(output); // --> 50.26548245743669
```
