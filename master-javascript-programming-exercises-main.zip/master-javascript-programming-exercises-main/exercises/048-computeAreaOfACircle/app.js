function computeAreaOfACircle(radius) {
    // your code here
}