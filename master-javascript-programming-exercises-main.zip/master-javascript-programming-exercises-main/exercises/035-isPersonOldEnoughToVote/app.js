function isPersonOldEnoughToVote(person) {
  // Add your code after this line
  
}