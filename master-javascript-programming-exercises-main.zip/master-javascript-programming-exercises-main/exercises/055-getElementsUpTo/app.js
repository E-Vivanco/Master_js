function getElementsUpTo(array, n) {
  // your code here
  
}