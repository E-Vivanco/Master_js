# `055` getElementsUpTo

## 📝 Instrucciones:

1. Escribe una función llamada `getElementsUpTo`. Dado un array y un índice, `getElementsUpTo`, regresa un array con todos los elementos hasta (pero sin incluir) el elemento en el índice dado.

## Ejemplo:

```Javascript
let output = getElementsUpTo(['a', 'b', 'c', 'd', 'e'], 3) 
console.log(output); // --> ['a', 'b', 'c']
```
## 💡 Pista:

+ Para poder hacer este ejercicio debes estar familiarizado con el método `slice`.