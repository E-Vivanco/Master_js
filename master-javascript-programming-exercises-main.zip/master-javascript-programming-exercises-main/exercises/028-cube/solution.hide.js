// Write your function here
function cube(n){
    return n * n * n
}