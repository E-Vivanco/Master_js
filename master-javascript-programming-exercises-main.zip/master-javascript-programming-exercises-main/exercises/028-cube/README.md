# `028` cube

## 📝 Instructions:

1. Write a function called `cube`. Given a number, `cube` returns the cube of that number.

## Example:

```Javascript
let output = cube(3);
console.log(output); // --> 27
```