# `028` Cube

## 📝 Instrucciones:

1. Escribe una función llamada `cube`. Dado un número, `cube` retorna el cubo de ese número.

## Ejemplo:

```Javascript
let output = cube(3);
console.log(output); // --> 27
```