function getProperty(obj, key) {
  // your code here
}