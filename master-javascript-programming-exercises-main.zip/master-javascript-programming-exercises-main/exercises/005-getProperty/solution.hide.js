function getProperty(obj, key) {
  // your code here
  return obj[key];
}