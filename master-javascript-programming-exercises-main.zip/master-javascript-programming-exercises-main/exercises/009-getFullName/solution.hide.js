function getFullName(firstName, lastName) {
  // your code here
  return firstName + " " + lastName
}