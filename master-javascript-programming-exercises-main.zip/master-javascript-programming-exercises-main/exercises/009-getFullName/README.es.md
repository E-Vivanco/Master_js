# `009` getFullName

## 📝 Instrucciones:

1. Escribe una función llamada `getFullName`. Dado un nombre y un apellido, `getFullName` retorna un string con el nombre y apellido separados por un espacio.

## Ejemplo:

```Javascript
let output = getFullName('Joe', 'Smith');
console.log(output); // --> 'Joe Smith'
```