function getFullName(firstName, lastName) {
  // your code here
}