# `050` computeSquareRoot

## 📝 Instructions:

1. Write a function called `computeSquareRoot`. Given a number, `computeSquareRoot` returns its square root.

## Example:

```Javascript
let output = computeSquareRoot(9);
console.log(output); // --> 3
```