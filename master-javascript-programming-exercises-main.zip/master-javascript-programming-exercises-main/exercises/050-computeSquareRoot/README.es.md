# `050` computeSquareRoot

## 📝 Instrucciones:

1. Escribe una función llamada `computeSquareRoot`. Dado un número, `computeSquareRoot` regresa su raíz cuadrada.

## Ejemplo:

```Javascript
let output = computeSquareRoot(9);
console.log(output); // --> 3
```