function computeSquareRoot(num) {
  // your code here
}