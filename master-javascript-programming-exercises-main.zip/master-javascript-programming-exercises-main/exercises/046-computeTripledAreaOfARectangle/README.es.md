# `046` computeTripledAreaOfARectangle

## 📝 Instrucciones:

1. Escribe una función llamada `computeTripledAreaOfARectangle`. Dado el largo y ancho de un rectángulo, `computeTripledAreaOfARectangle` regresa el área del rectángulo, multiplicado por 3.

## Ejemplo:

```Javascript
let output = computeTripledAreaOfARectangle(2, 4);
console.log(output); // --> 24
```