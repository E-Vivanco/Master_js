# `046` computeTripledAreaOfARectangle

## 📝 Instructions:

1. Write a function called `computeTripledAreaOfARectangle`. Given a length and width of a rectangle, `computeTripledAreaOfARectangle` returns the rectangle’s area, multiplied by 3.

## Example:

```Javascript
let output = computeTripledAreaOfARectangle(2, 4);
console.log(output); // --> 24
```