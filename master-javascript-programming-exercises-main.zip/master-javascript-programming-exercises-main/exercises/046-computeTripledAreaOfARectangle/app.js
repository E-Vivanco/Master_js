function computeTripledAreaOfARectangle(length, width) {
  // your code here
  
}