# `007` removeProperty

## 📝 Instrucciones:

1. Escribe una función llamada `removeProperty`. Dado un objeto y una key, `removeProperty` elimina esa llave de ese objeto dado.

## Ejemplo:

```Javascript
let obj = {
  name: 'Sam',
  age: 20
}
removeProperty(obj, 'name');
console.log(obj.name); // --> undefined
```

## 💡 Pista
+ https://developer.mozilla.org/es/docs/Web/JavaScript/Reference/Operators/delete