function removeProperty(obj, key) {
  // your code here
}