# `029` square

## 📝 Instructions

1. Write a function called `square`. Given a number, `square` should return the square of the given number.

## Example

```Javascript
let output = square(5);
console.log(output); // --> 25
```