// Write your function here
function square(n){
    return n * n
}