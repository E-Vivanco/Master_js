# `029` square

## 📝 Instrucciones:

1. Escribe una función llamada `square`. Dado un número, `square` retorna el cuadrado de dicho número.

## Ejemplo:

```Javascript
let output = square(5);
console.log(output); // --> 25
```