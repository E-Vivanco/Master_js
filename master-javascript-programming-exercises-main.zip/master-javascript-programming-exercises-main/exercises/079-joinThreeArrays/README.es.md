# `079` joinThreeArrays

## 📝 Instrucciones:

1. Escribe una función llamada `joinThreeArrays`. Dados tres arrays, `joinThreeArrays` regresa un array con los elementos de `arr1` seguido por los elementos del `arr2` y del `arr3` en orden.

## Ejemplo:

```Javascript
let output = joinThreeArrays([1, 2], [3, 4], [5, 6]);
console.log(output); // --> [1, 2, 3, 4, 5, 6]
```

## 💡 Pista:

+ Deberías estar familiarizado con el método `concat` para este problema. 