function joinThreeArrays(arr1, arr2, arr3) {
  // your code here
  
}