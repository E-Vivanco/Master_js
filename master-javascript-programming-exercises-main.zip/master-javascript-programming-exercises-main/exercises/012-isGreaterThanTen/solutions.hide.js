function isGreaterThanTen(num) {
  // your code here
  if(num > 10) return true
  else return false
}