function isGreaterThanTen(num) {
  // your code here
}