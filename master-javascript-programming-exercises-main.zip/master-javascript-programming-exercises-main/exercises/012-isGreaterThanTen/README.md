# `012` isGreaterThanTen

## 📝 Instructions: 

1. Write a function called `isGreaterThanTen`. Given a number, `isGreaterThanTen` returns `true` if it is greater than 10, otherwise it returns `false`.

## Example:

```Javascript
let output = isGreaterThanTen(11);
console.log(output); // --> true
```