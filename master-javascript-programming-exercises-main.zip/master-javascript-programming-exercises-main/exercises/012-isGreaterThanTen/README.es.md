# `012` isGreaterThanTen

## 📝 Instrucciones:

1. Escribe una función llamada `isGreaterThanTen`. Dado un número, `isGreaterThanTen` retorna `true` si éste es mayor a 10, sino retorna `false`.

## Ejemplo:

```Javascript
let output = isGreaterThanTen(11);
console.log(output); // --> true
```
