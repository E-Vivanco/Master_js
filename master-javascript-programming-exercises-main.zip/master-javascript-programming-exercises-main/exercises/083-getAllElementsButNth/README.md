# `083` getAllElementsButNth

## 📝 Instructions 

1. Write a function called `getAllElementsButNth`. Given an array and an index, `getAllElementsButNth` returns an array with all the elements but the nth.

## Example:

```js
let output = getAllElementsButNth(['a', 'b', 'c'], 1);
console.log(output); // --> ['a', 'c']
```