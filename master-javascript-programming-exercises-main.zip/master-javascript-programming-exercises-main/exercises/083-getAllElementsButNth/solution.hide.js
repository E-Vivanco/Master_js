


























function getAllElementsButNth(array, n) {
    // Write your function here
    array.splice(n, 1);
    return array
}