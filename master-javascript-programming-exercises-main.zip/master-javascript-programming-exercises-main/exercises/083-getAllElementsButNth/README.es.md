# `083` getAllElementsButNth

## 📝 Instrucciones: 

1. Escribe una función llamada `getAllElementsButNth`. Dado un array y un índice, `getAllElementsButNth` retorna un array con todos los elementos salvo el nth.

## Ejemplo:

```js
let output = getAllElementsButNth(['a', 'b', 'c'], 1);
console.log(output); // --> ['a', 'c']
```