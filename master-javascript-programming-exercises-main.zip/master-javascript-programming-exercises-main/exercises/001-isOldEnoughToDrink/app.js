function isOldEnoughToDrink(age){
    // your code here	
}