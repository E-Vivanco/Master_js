# `001` isOldEnoughToDrink

## 📝 Instrucciones:

1. Escribe una función llamada `isOldEnoughToDrink`. Dado un número, en este caso una edad, `isOldEnoughToDrink` retorna si la persona de esa edad tiene la edad necesaria para beber legalmente en los Estados Unidos.

## Ejemplo:

```javascript
let output = isOldEnoughToDrink(22);
console.log(output); // --> true
```

## 💡 Pista:

+ La edad legal para poder beber en los Estados Unidos es de 21 años.
