# `066` isEitherEvenOrAreBoth7

## 📝 Instrucciones:

1. Escribe una función llamada `isEitherEvenOrAreBoth7`. Dados dos números, `isEitherEvenOrAreBoth7`  regresa `true` si alguno de los parámetros es par o los dos son 7. En caso contrario regresa `false`. 

## Ejemplos:

```Javascript
let output = isEitherEvenOrAreBoth7(3, 7);
console.log(output); // --> false

let output = isEitherEvenOrAreBoth7(2, 3);
console.log(output); // --> true
```