function isEitherEvenOrAreBoth7(num1, num2) {
    // your code here
    
}
