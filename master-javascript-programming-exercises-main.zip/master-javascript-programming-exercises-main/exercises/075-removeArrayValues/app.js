function removeArrayValues(obj) {
    // your code here
    
}