function getLastElement(array) {
  // Add your code after this line
  return 4
}