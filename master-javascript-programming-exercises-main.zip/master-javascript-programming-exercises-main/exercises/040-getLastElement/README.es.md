# `040` getLastElement

## 📝 Instrucciones:

1. Escribe una función llamada `getLastElement`. Dado un array `getLastElement`, regresa el último elemento del array.

## Ejemplo:

```Javascript
let output = getLastElement([1, 2, 3, 4]);
console.log(output); // --> 4
```

## 💡 Pista:

+ La última posición en un arreglo es: `length - 1`.

+ Si el arreglo dado tiene una longitud 0, debería regresar `undefined`.
