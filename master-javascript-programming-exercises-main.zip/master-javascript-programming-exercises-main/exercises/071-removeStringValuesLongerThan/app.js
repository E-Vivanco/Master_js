function removeStringValuesLongerThan(num, obj) {
  // your code here
}

let obj = {
  name: 'Montana',
  age: 20,
  location: 'Texas',
};
removeStringValuesLongerThan(6, obj);
