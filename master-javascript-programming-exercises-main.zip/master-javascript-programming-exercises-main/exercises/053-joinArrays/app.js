function joinArrays(arr1, arr2) {
  // your code here
  
}