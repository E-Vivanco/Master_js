# `053` joinArrays

## 📝 Instructions:

1. Write a function called `joinArrays`. Given 2 arrays, `joinArrays` returns an array with the elements of `arr1`, followed by the elements of `arr2` in order.

## Example:

```Javascript
let output = joinArrays([1, 2], [3, 4]);
console.log(output); // --> [1, 2, 3, 4]
```
## 💡 Hint:

+ You should use the concat method.
