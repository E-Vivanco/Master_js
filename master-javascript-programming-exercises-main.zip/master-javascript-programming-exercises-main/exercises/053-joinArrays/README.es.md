# `053` joinArrays

## 📝 Instrucciones:

1. Escribe una función llamada `joinArrays`. Dados dos arrays, `joinArrays` regresa un array con los elementos de `arr1`, seguido por los elementos de `arr2` en orden. 

## Ejemplo:

```Javascript
let output = joinArrays([1, 2], [3, 4]);
console.log(output); // --> [1, 2, 3, 4]
```

## 💡 Pista:

+ Deberías estar familiarizado con el método `concat` para este problema. 