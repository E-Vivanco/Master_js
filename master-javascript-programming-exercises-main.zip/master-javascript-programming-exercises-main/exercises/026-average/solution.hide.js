// Write your function here
function average(a,b){
    return (a+b)/2
}