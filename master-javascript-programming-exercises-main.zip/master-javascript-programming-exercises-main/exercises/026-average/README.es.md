# `026` Average

## 📝 Instrucciones:

1. Escribe una función llamada `average`. Dado 2 números, `average` retorna su promedio.

## Ejemplo:

```Javascript
let output = average(4, 6);
console.log(output); // --> 5
```