# `026` Average

## 📝 Instructions:

1. Write a function called `average`. Given two numbers, `average` returns their average.

## Example:

```Javascript
let output = average(4, 6);
console.log(output); // --> 5
```