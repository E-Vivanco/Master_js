# `065` or

## 📝 Instructions:

1. Write a function called `or`. Given 2 boolean expressions, `or` returns true or false, corresponding to the `||` operator.

## Example:

```Javascript
let output = or(true, false);
console.log(output); // --> true;
```

## 💡 Hints:

+ Don't use the `||` operator. 

+ Use `!` and `&&` operators instead.
