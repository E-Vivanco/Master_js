function or(expression1, expression2) {
  // your code here
  
}