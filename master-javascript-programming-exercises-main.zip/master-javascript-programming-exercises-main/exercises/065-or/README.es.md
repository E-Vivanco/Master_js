# `065` or

## 📝 Instrucciones:

1. Escribe una función llamada `or`. Dadas 2 expresiones booleanas, `or` regresa true o false, correspondiente al operador `||`.

## Ejemplo:

```Javascript
let output = or(true, false);
console.log(output); // --> true;
```

## 💡 Pistas:

+ No utilices el operador `||`.

+ Usa `!` y operadores `&&` en su lugar.