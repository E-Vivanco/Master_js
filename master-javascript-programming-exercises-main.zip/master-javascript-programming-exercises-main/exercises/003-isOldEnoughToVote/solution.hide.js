function isOldEnoughToVote(age) {
  // your code here
  if(age >20) return true;
  else return false;
}