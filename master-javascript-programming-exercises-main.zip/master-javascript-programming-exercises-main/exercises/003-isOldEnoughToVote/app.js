function isOldEnoughToVote(age) {
  // your code here
}