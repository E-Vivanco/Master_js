# `003` isOldEnoughToVote

## 📝 Insructions:

1. Write a function called `isOldEnoughToVote`. Given a number, in this case an age, `isOldEnoughToVote` returns whether a person of this given age is old enough to legally vote in the United States.

## Example:

```Javascript
let output = isOldEnoughToVote(22);
console.log(output); // --> true
```

## 💡 Hint:

+ The legal voting age in the United States is 18.