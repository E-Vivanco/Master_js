function getAverageOfElementsAtProperty(obj, key) {
  // your code here

}