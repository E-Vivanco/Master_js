# `013` isLessThan30

## 📝 Instructions: 

1. Write a function called `isLessThan30`. Given a number, `isLessThan30` returns `true` if the given number is less than 30. Otherwise it returns `false`.

## Example:

```Javascript
let output = isLessThan30(9);
console.log(output); // --> true
```