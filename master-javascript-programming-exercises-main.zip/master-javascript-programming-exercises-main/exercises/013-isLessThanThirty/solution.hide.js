function isLessThan30(num) {
  // your code here
  if(num < 30) return true
  else return false
}