function isLessThan30(num) {
  // your code here
}