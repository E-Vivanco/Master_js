# `013` isLessThan30

## 📝 Instrucciones:

1. Escribe una función llamada `isLessThan30`. Dado un número, `isLessThan30` retorna `true` si ese número es menor de 30. De lo contrario retorna `false`.

## Ejemplo:

```Javascript
let output = isLessThan30(9);
console.log(output); // --> true (verdadero)
```