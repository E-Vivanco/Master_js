# `010` getLengthOfWord

## 📝 Instrucciones:

1. Escribe una función llamada `getLengthOfWord`. Dada un palabra, `getLengthOfWord` debe retornar la cantidad de letras que tiene esa palabra.

## Ejemplo:

```Javascript
let output = getLengthOfWord('some');
console.log(output); // --> 4
```
