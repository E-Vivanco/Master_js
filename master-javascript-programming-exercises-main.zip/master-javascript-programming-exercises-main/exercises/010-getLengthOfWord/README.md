# `010` getLengthOfWord

## 📝 Instructions 

1. Write a function called `getLengthOfWord`. Given a word, `getLengthOfWord` returns the length of the given word.

## Example:

```Javascript
let output = getLengthOfWord('some');
console.log(output); // --> 4
```