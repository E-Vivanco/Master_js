function getLengthOfWord(word) {
  // your code here
}