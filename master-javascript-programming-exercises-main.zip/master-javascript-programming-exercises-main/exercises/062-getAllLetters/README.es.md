# `062` getAllLetters

## 📝 Instrucciones:

1. Escribe una función llamada `getAllLetters`. Dado una palabra, `getAllLetters` regresa un array que contenga todos los caracteres de la palabra. 

## Ejemplo:

```Javascript
let output = getAllLetters('Radagast');
console.log(output); // --> ['R', 'a', 'd', 'a', 'g', 'a', 's', 't']
```

## 💡 Pista:

+ Si se da un string vacío, debe regresar un array vacío.