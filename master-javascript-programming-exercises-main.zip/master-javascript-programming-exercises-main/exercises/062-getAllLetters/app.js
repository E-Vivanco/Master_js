function getAllLetters(str) {
    // your code here
    
}