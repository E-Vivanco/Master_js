// Write your function here
function computeAverageLengthOfWords(word1, word2){
    return (word1.length + word2.length) /2
}