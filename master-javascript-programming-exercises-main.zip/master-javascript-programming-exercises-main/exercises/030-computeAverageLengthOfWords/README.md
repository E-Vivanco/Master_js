# `030` computeAverageLengthOfWords

## 📝 Instructions:

1. Write a function called `computeAverageLengthOfWords`. Given two words, `computeAverageLengthOfWords` returns the average of their lengths.

## Example:

```Javascript
let output = computeAverageLengthOfWords('code', 'programs');
console.log(output); // --> 6
```