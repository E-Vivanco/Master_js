# `030` computeAverageLengthOfWords

## 📝 Instrucciones:

1. Escribe una función llamada `computeAverageLengthOfWords`. Dado dos palabras, `computeAverageLengthOfWords` retorna el promedio de la cantidad de letras de ambas.

## Ejemplo:

```Javascript
let output = computeAverageLengthOfWords('code', 'programs');
console.log(output); // --> 6
```