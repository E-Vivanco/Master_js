# `067` isEitherEvenAndLessThan9

## 📝 Instructions:

1. Write a function called `isEitherEvenAndLessThan9`. Given 2 numbers, `isEitherEvenAndLessThan9` should return `true` only if one of the numbers is even and both are less than 9, otherwise it must return `false`.

## Examples:

```Javascript
let output = isEitherEvenAndLessThan9(2, 4);
console.log(output); // --> true

let output = isEitherEvenAndLessThan9(72, 2);
console.log(output); // --> false
```