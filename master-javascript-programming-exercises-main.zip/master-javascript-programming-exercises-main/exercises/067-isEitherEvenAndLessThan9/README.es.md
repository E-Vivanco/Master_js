# `067` isEitherEvenAndLessThan9

## 📝 Instrucciones:

1. Escribe una función llamada `isEitherEvenAndLessThan9`. Dados dos números, `isEitherEvenAndLessThan9` retorna `true` si alguno de los dos parámetros es par y los dos son menores de 9, de otra forma debe retornar `false`.

## Ejemplos:

```Javascript
let output = isEitherEvenAndLessThan9(2, 4);
console.log(output); // --> true

let output = isEitherEvenAndLessThan9(72, 2);
console.log(output); // --> false
```
