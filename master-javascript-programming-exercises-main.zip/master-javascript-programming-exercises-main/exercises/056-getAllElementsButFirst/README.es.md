# `56` getAllElementsButFirst

## 📝 Instrucciones:

1. Escribe una función llamada `getAllElementsButFirst`. Dado un array, `getAllElementsButFirst` regresa un array con todos los elementos excepto el primero.

## Ejemplo:

```Javascript
let input = [1, 2, 3, 4];
let output = getAllElementsButFirst(input);
console.log(output); // --> [2, 3, 4]
```