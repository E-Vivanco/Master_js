# `056` getAllElementsButFirst

## 📝 Instructions:

1. Write a function called `getAllElementsButFirst`. Given an array, `getAllElementsButFirst` returns an array with all the elements but not the first.

## Example:

```Javascript
let input = [1, 2, 3, 4];
let output = getAllElementsButFirst(input);
console.log(output); // --> [2, 3, 4]
```