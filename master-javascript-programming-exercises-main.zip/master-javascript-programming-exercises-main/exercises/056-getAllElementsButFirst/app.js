function getAllElementsButFirst(array) {
  // your code here
  
}