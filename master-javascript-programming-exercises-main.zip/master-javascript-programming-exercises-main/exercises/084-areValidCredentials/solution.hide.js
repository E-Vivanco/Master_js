function areValidCredentials(name, pass){
    return name.length > 3 && pass.length >= 8 ? true : false;
}