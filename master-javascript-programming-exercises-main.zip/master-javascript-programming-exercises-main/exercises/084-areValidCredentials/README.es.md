# `084` areValidCredentials

## 📝 Instrucciones: 

1. Escribe una función llamada `areValidCredentials`. Dado un nombre y una contraseña,  `areValidCredentials` retorna verdadero si el nombre tiene más de 3 caracteres. 

2. La contraseña debe tener por lo menos 8 caracteres de lo contrario debe retornar falso.

## Ejemplo:

```js
let output = areValidCredentials('Ritu', 'mylongpassword')
console.log(output); // --> verdadero
```
