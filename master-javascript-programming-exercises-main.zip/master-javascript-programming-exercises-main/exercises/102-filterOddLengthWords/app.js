function filterOddLengthWords(words) {
    // your code here
}

let output = filterOddLengthWords(['there', 'it', 'is', 'now']);
console.log(output); // --> ['there', "now']