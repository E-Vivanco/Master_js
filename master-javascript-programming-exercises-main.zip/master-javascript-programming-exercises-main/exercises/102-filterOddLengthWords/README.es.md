# `102` filterOddLengthWords

## 📝 Instrucciones

1. Escribe una función llamada `filterOddLengthWords`. Dado un array de strings, `filterOddLengthWords` regresa un array que contenga únicamente los elementos del array dado cuya length sea números impares.

## Ejemplo:

```js
let output = filterOddLengthWords(['there', 'it', 'is', 'now']);
console.log(output); // --> ['there', "now']
```

## 💡 Pista:

- Si el array está vacío, debe regresar un array vacío `[]`.

- Si no contiene ningún elemento cuyo length es impar, debe regresar un array vacío `[]`.
