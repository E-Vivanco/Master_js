function addArrayProperty(obj, key, arr) {
  // Add your code after this line
  
}