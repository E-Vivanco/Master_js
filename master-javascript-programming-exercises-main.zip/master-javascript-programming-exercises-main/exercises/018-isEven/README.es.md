# `018` isEven

## 📝 Instrucciones:

1. Escribe una función llamada `isEven`. Dado un número, `isEven` retorna `true` si el número es par. De lo contrario retorna `false`.

## Ejemplo:

```Javascript
let output = isEven(11);
console.log(output); // --> falso
```