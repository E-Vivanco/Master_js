// Write your function here
function isEven(num){
    return num % 2 === 0
}