# `018` isEven

## 📝 Instructions:

1. Write a function called `isEven`. Given a number, `isEven` returns `true` if it is even. Otherwise it returns `false`.

## Example:

```Javascript
let output = isEven(11);
console.log(output); // --> false
```
