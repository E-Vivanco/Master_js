function removeOddValues(obj) {
    // your code here

}