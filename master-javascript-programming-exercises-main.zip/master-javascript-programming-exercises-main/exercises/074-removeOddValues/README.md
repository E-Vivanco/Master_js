# `074` removeOddValues

## 📝 Instructions:

1. Write a function called `removeOddValues`. Given an object, `removeOddValues` removes any properties whose values are odd numbers.

## Example:

```Javascript
let obj = {
  a: 2,
  b: 3,
  c: 4
};
removeOddValues(obj);
console.log(obj); // --> { a: 2, c: 4 }
```