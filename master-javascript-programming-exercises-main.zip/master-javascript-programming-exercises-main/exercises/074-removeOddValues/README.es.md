# `074` removeOddValues

## 📝 Instrucciones:

1. Escribe una función llamada `removeOddValues"`. Dado un objeto, `removeOddValues` elimina cualquier propiedad cuyos valores son números impares.

## Ejemplo:

```Javascript
let obj = {
  a: 2,
  b: 3,
  c: 4
};
removeOddValues(obj);
console.log(obj); // --> { a: 2, c: 4 }
```