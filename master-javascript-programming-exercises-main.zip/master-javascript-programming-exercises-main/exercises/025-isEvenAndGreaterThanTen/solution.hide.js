// Write your function here
function isEvenAndGreaterThanTen(numb){
    return numb > 10 && numb % 2 === 0
}