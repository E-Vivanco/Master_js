# `025` isEvenAndGreaterThanTen

## 📝 Instructions:

1. Write a function called `isEvenAndGreaterThanTen`. Given a number, `isEvenAndGreaterThanTen` returns `true` if the number is both even and greater than 10, otherwise it returns `false`.

## Example:

```Javascript
let output = isEvenAndGreaterThanTen(13);
console.log(output); // --> false
```
