# `025` isEvenAndGreaterThanTen

## 📝 Instrucciones:

1. Escribe una función llamada `isEvenAndGreaterThanTen`. Dado un número, `isEvenAndGreaterThanTen` retorna `true` si el número es par y mayor que 10, de lo contrario retorna `false`.

## Ejemplo:

```Javascript
let output = isEvenAndGreaterThanTen(13);
console.log(output); // --> false
```
