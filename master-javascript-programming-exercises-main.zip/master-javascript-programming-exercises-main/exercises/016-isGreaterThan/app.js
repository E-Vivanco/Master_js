function isGreaterThan(num1, num2) {
  // your code here
}