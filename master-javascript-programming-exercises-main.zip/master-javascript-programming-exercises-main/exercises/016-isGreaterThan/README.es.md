# `016` isGreaterThan

## 📝 Instrucciones:

1. Escribe una función llamada `isGreaterThan`. Dado 2 números, `isGreaterThan` retorna `true` si `num2` es mayor que `num1`. De lo contrario retorna `false`.

## Ejemplo:

```Javascript
let output = isGreaterThan(11, 10);
console.log(output); // --> false
```