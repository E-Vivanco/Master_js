# `016` isGreaterThan

## 📝 Instructions:

1. Write a function called `isGreaterThan`. Given 2 numbers, `isGreaterThan` returns `true` if `num2` is greater than `num1`. Otherwise it returns `false`.

## Example:

```Javascript
let output = isGreaterThan(11, 10);
console.log(output); // --> false
```