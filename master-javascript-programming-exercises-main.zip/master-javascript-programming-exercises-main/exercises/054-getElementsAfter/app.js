function getElementsAfter(array, n) {
  // your code here
  
}