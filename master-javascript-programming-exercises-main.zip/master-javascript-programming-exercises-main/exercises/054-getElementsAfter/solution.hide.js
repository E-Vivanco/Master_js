// array = ['a', 'b', 'c', 'd', 'e']
// array.slice(n) = [ 'c', 'd', 'e']

// array.splice(n + 1) = [ 'd', 'e']