# `041` addToFront

## 📝 Instrucciones:

1. Escribe una función llamada `addToFront`. Dado un array y un elemento, `addToFront` añade el elemento al frente del array, y regresa el array dado.

## Ejemplo:

```Javascript
let output = addToFront([1, 2], 3);
console.log(output); // -> [3, 1, 2]
```

## 💡 Pista:

+ Debería ser el MISMO arreglo, no uno nuevo.