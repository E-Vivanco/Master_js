//Hint: you can use unshift
const hint= () => {
    let Old_array = [1, 2, 3]
    Old_array.unshift(4);   
    console.log(Old_array); // -> 4, 1, 2, 3
}