# `099` computeAverageOfNumbers

## 📝 Instructions: 

1. Write a function called `computeAverageOfNumbers`. Given an array of numbers, `computeAverageOfNumbers` returns their average. 

## Example:

```js
let input = [1,2,3,4,5];
let output = computeAverageOfNumbers(input);
console.log(output); // --> 3
```

## 💡 Hint:

+ If given an empty array, it should return 0.