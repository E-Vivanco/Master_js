# `017` isEqualTo

## 📝 Instrucciones: 

1. Escribe una función llamada `isEqualTo`. Dado 2 números, `isEqualTo` retorna si `true` si `num2` es igual a `num1`. De lo contrario retorna `false`.

## Ejemplo:

```Javascript
let output = isEqualTo(11, 10);
console.log(output); // --> false
