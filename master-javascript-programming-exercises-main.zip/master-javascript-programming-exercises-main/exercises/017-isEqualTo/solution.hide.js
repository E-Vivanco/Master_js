// Write your function here
function isEqualTo(a,b){
    return a===b
}