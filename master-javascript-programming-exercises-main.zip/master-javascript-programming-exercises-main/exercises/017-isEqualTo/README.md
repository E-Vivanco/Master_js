# `017` isEqualTo

## 📝 Instructions: 

1. Write a function called `isEqualTo`. Given 2 numbers, `isEqualTo` returns `true` if `num2` is equal to `num1`. Otherwise it returns `false`.

## Example:

```Javascript
let output = isEqualTo(11, 10);
console.log(output); // --> false
```