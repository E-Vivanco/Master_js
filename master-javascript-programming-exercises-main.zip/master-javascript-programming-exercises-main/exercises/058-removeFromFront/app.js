function removeFromFront(arr) {
    // your code here
    
}