# `058` removeFromFront

## 📝 Instrucciones:

1. Escribe una función llamada `removeFromFront`. Dado un array, `removeFromFront` regresa el array con su primer elemento eliminado.

## Ejemplo:

```Javascript
let output = removeFromFront([1, 2, 3]);
console.log(output); // --> [2, 3]
```
## 💡 Pista:

* Deberías estar familiarizado con el métedo `shift`.
