function addFullNameProperty(obj) {
  // Add your code after this line
  
}