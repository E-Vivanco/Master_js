# `064` removeFromBack

## 📝 Instrucciones:

1. Escribe una función llamada `removeFromBack`. Dado un array, `removeFromBack` regresa el array con su último elemento eliminado.

## Ejemplo:

```Javascript
let output = removeFromBack([1, 2, 3]);
console.log(output); // --> [1, 2]
```

## 💡 Pista:

+ Debes estar familiarizado con el método `pop`.