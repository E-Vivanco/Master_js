# `064` removeFromBack

## 📝 Instructions:

1. Write a function called `removeFromBack`. Given an array, `removeFromBack"` returns the array with its last element removed.

## Example:
 
```Javascript
let output = removeFromBack([1, 2, 3]);
console.log(output); // --> [1, 2]
```

## 💡 Hint:

+ You should be familiar with the `pop` method.