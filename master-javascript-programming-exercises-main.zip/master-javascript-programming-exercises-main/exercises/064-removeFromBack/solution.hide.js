function removeFromBack(arr) {
    // your code here
    return arr.slice(0,-1)
}