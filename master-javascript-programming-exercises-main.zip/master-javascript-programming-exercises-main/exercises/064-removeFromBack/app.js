function removeFromBack(arr) {
    // your code here
    
}