function computePerimeterOfACircle(radius) {
  // your code here

}