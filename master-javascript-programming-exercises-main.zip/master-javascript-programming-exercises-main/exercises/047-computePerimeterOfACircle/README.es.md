# `047` computePerimeterOfACircle

## 📝 Instrucciones:

1. Escribe la función llamada `computePerimeterOfACircle`. Dado el radio de un círculo, `computePerimeterOfACircle` regresa su perímetro.

## Ejemplo:

```Javascript
let output = computePerimeterOfACircle(4);
console.log(output); // --> 25.132741228718345
```