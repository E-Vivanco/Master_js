# `047` computePerimeterOfACircle

## 📝 Instructions:

1. Write a function called `computePerimeterOfACircle`. Given the radius of a circle `computePerimeterOfACircle` returns its perimeter.

## Example:

```Javascript
let output = computePerimeterOfACircle(4);
console.log(output); // --> 25.132741228718345
```