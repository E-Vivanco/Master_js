function getAllWords(str) {
    // your code here
    
}
