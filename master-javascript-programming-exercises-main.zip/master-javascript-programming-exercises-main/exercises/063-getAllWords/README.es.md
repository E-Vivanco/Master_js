# `063` getAllWords

## 📝 Instrucciones:

1. Escribe una función llamada `getAllWords`. Dado una oración, `getAllWords` regresa un array que contenga cada palabra de la oración. 

## Ejemplo:

```Javascript
let output = getAllWords('Radagast the Brown');
console.log(output); // --> ['Radagast', 'the', 'Brown']
```

## 💡 Pista:

+ Si se da un string vacío, debe regresar un array vacío.