function removeFromFrontOfNew(arr) {
    // your code here
    
}