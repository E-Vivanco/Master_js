# `060` removeFromFrontOfNew

## 📝 Instrucciones:

1. Escribe una función llamada `removeFromFrontOfNew`. Dado un array, `removeFromFrontOfNew` regresa un nuevo array que contenga todos los elementos menos el primero del array dado. 

## Ejemplo:

```Javascript
let arr = [1, 2, 3];
let output = removeFromFrontOfNew(arr);
console.log(output); // --> [2, 3]
console.log(arr); // --> [1, 2, 3]
```

## 💡 Pista: 

+ Debes estar familiarizado con el método `shift`.