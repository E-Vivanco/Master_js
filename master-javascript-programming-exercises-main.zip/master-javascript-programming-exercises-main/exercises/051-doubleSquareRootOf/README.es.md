# `051` doubleSquareRootOf

## 📝 Instrucciones:

1. Escribe una función llamada `doubleSquareRootOf`. Dado un número, `doubleSquareRootOf` regresa el doble de su raíz cuadrada. Basicamente retorna la raíz cuadrada del número multiplicada por 2.

## Ejemplo:

```Javascript
let output = doubleSquareRootOf(121);
console.log(output); // --> 22
```