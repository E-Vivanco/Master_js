function doubleSquareRootOf(num) {
  // your code here
  
}