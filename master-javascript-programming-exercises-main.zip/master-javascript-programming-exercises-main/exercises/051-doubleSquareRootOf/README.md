# `051` doubleSquareRootOf

## 📝 Instructions:

1. Write a function called `doubleSquareRootOf`. Given a number, `doubleSquareRootOf` returns double its square root. It basically returns the square root of the number multiplied by 2.

## Example:

```Javascript
let output = doubleSquareRootOf(121);
console.log(output); // --> 22
```