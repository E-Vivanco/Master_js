# `043` computeAreaOfARectangle

## 📝 Instructions:

1. Write a function called `computeAreaOfARectangle`. Given the length and width of a rectangle `computeAreaOfARectangle` returns its area.

## Example:

```Javascript
let output = computeAreaOfARectangle(4, 8);
console.log(output); // --> 32
```