function computeAreaOfARectangle(length, width) {
  // your code here

}

let output = computeAreaOfARectangle(10, 18);
console.log(output)