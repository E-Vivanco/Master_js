# `043` computeAreaOfARectangle

## 📝 Instrucciones:

1. Escribe una función llamada `computeAreaOfARectangle`. Dado el largo y ancho de un rectágulo, `computeAreaOfARectangle` regresa su área.

## Ejemplo:

```Javascript
let output = computeAreaOfARectangle(4, 8);
console.log(output); // --> 32
```
