function computePerimeterOfATriangle(side1, side2, side3) {
  // your code here
}