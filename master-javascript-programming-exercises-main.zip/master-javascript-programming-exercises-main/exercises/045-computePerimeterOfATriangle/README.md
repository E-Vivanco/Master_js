# `045` computePerimeterOfATriangle

## 📝 Instructions:

1. Write a function called `computePerimeterOfATriangle`. Given 3 sides describing a triangle, `computePerimeterOfATriangle` returns its perimeter.

## Example:

```Javascript
let output = computePerimeterOfATriangle(6, 4, 10);
console.log(output); // --> 20 
```