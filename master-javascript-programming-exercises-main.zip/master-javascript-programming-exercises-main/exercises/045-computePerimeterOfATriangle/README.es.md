# `045` computePerimeterOfATriangle

## 📝 Instrucciones:

1. Escribe una función llamada `computePerimeterOfATriangle`. Dado 3 lados de un triángulo, `computePerimeterOfATriangle` regresa su perímetro.

## Ejemplo:

```Javascript
let output = computePerimeterOfATriangle(6, 4, 10);
console.log(output); // --> 20 
```