# `081` addToFrontOfNew

## 📝 Instrucciones:

1. Escribe una función llamada `addToFrontOfNew`. Dado un array y un elemento, `addToFrontOfNew` retorna una nuevo array que contiene todos los elementos de ese array más el elemento dado añadido en primer lugar.

## Ejemplo:

```js
let input = [1, 2];
let output = addToFrontOfNew(input, 3);
console.log(output); // --> [3, 1, 2];
console.log(input); --> [1, 2]
```

## 💡 Pista:

+  Debería crear un nuevo array y no modificar el array original. 
